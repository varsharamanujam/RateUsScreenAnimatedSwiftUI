//
//  endcallApp.swift
//  endcall
//
//  Created by Varsha Sureshbabu on 26/11/21.
//

import SwiftUI

@main
struct endcallApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
