//
//  LottieView.swift
//  endcall
//
//  Created by Varsha Sureshbabu on 27/11/21.
//
import Lottie
import SwiftUI
import UIKit

struct LottieView: UIViewRepresentable{
typealias UIViewType = UIView
func makeUIView(context: UIViewRepresentableContext<LottieView>) -> UIView {
    let view = UIView(frame: .zero)
    
    let animationView = AnimationView()
    let animation = Animation.named("11.34")
    animationView.animation = animation
    animationView.contentMode = .scaleAspectFit
    animationView.animationSpeed = 1.5
    animationView.play()
    animationView.translatesAutoresizingMaskIntoConstraints = false
    view.addSubview(animationView)
    
    NSLayoutConstraint.activate([
    animationView.widthAnchor.constraint(equalTo: view.widthAnchor),
    animationView.heightAnchor.constraint(equalTo: view.heightAnchor)
    ])
    
    return view

}
func updateUIView(_ uiView: UIView, context: UIViewRepresentableContext<LottieView>) {
//
    
}
}
