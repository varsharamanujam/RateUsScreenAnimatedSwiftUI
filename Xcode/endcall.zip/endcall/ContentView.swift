//
//  ContentView.swift
//  endcall
//
//  Created by Varsha Sureshbabu on 26/11/21.
//

import SwiftUI
import UIKit

struct ContentView: View {
    @State private var rating : Int?
    var body: some View {
            
    
        ZStack {
            LinearGradient(colors: [Color.cyan.opacity(0.2),Color.purple.opacity(0.5)], startPoint: .topLeading, endPoint: .bottomTrailing)
            
            Circle().frame(width: 300).foregroundColor(Color.blue.opacity(0.1)).blur(radius: 25).offset(x: -100,y: -150)
            
            RoundedRectangle(cornerRadius: 30,style: .continuous).frame(width: 500, height: 500).foregroundStyle(LinearGradient(colors:[Color.purple.opacity(0.4), Color.mint.opacity(0.2)], startPoint: .top, endPoint: .leading))
                .offset(x: 300).blur(radius: 30).rotationEffect(.degrees(30))
            
            Circle().frame(width:450).foregroundColor(Color.pink.opacity(0.2)).blur(radius: 40).offset(x: 200,y: -300)
            
            VStack(alignment: .center){
                            Text("Trip with your Avvtar has ended !").font(.title3).fontWeight(.bold).multilineTextAlignment(.center).padding(.top, -110.0)
                            
                            LottieView().padding(.top, -80.0).frame(width: 400, height: 300, alignment: .center )
            }
            Spacer()
            VStack(alignment: .center){
                            
                            Text("Rate Us")
                                .padding(.top, -45.0).font(.title3)
                            
                            RatingView (rating: $rating)
                                .padding(.top, -20.0).font(.title)
                            
                            Text("Thank You for choosing Fonetrip").multilineTextAlignment(.center).padding(.top, 70).frame( height: 20,alignment: .center)
            }.padding(.all).frame(width:  350, height: 200).foregroundStyle(LinearGradient(colors: [.blue,.indigo], startPoint: .top, endPoint: .bottom))
                .background(.ultraThinMaterial,in: RoundedRectangle(cornerRadius: 12,style:.continuous)).offset(y: 250)
                
        }
        .edgesIgnoringSafeArea(.all)
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
            ContentView()
        }
    }
}
